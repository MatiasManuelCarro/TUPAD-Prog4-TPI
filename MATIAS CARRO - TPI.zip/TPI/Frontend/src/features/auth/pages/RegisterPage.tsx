import { useState } from "react";
import { useForm } from "@tanstack/react-form";
import { Link, useNavigate } from "react-router-dom";

import { registerUser } from "../services/authService";
import { handleApiError } from "@/shared/api/handleApiError";
import { Input } from "@/shared/components/ui/Input";

import type { RegisterData } from "../types/auth.types";

export const RegisterPage = () => {
  const navigate = useNavigate();

  const [errorMessage, setErrorMessage] = useState<
    string | null
  >(null);

  const [isPending, setIsPending] = useState(false);

  const form = useForm({
    defaultValues: {
      username: "",
      full_name: "",
      email: "",
      password: "",
    },

    onSubmit: async ({ value }) => {
      setErrorMessage(null);
      setIsPending(true);

      const data: RegisterData = {
        username: value.username.trim(),
        full_name: value.full_name.trim(),
        email: value.email.trim(),
        password: value.password,
      };

      try {
        await registerUser(data);

        navigate("/login");
      } catch (error: unknown) {
        setErrorMessage(
          handleApiError(
            error,
            "No se pudo completar el registro",
          ),
        );
      } finally {
        setIsPending(false);
      }
    },
  });

  return (
    <main
      className="
        mx-auto
        flex
        w-full
        max-w-md
        flex-1
        items-center
        p-6
      "
    >
      <div
        className="
          w-full
          rounded-xl
          border
          border-app-border
          bg-app-surface
          p-6
          shadow-sm
        "
      >
        <div className="mb-6">
          <h1
            className="
              text-3xl
              font-bold
              text-app-text
            "
          >
            Crear cuenta
          </h1>

          <p className="mt-1 text-app-text/70">
            Completa tus datos para registrarte.
          </p>
        </div>

        <form
          className="space-y-4"
          onSubmit={(event) => {
            event.preventDefault();

            if (isPending) {
              return;
            }

            form.handleSubmit();
          }}
        >
          <form.Field
            name="username"
            validators={{
              onChange: ({ value }) =>
                value.trim().length === 0
                  ? "El usuario es obligatorio"
                  : undefined,
            }}
          >
            {(field) => (
              <div>
                <label
                  htmlFor={field.name}
                  className="
                    mb-1
                    block
                    font-medium
                    text-app-text
                  "
                >
                  Usuario
                </label>

                <Input
                  id={field.name}
                  name={field.name}
                  type="text"
                  value={field.state.value}
                  onChange={(event) =>
                    field.handleChange(
                      event.target.value,
                    )
                  }
                  autoComplete="username"
                />

                {!field.state.meta.isValid && (
                  <p className="mt-1 text-sm text-app-danger">
                    {field.state.meta.errors.join(", ")}
                  </p>
                )}
              </div>
            )}
          </form.Field>

          <form.Field
            name="full_name"
            validators={{
              onChange: ({ value }) =>
                value.trim().length === 0
                  ? "El nombre completo es obligatorio"
                  : undefined,
            }}
          >
            {(field) => (
              <div>
                <label
                  htmlFor={field.name}
                  className="
                    mb-1
                    block
                    font-medium
                    text-app-text
                  "
                >
                  Nombre completo
                </label>

                <Input
                  id={field.name}
                  name={field.name}
                  type="text"
                  value={field.state.value}
                  onChange={(event) =>
                    field.handleChange(
                      event.target.value,
                    )
                  }
                  autoComplete="name"
                />

                {!field.state.meta.isValid && (
                  <p className="mt-1 text-sm text-app-danger">
                    {field.state.meta.errors.join(", ")}
                  </p>
                )}
              </div>
            )}
          </form.Field>

          <form.Field
            name="email"
            validators={{
              onChange: ({ value }) =>
                value.trim().length === 0
                  ? "El email es obligatorio"
                  : undefined,
            }}
          >
            {(field) => (
              <div>
                <label
                  htmlFor={field.name}
                  className="
                    mb-1
                    block
                    font-medium
                    text-app-text
                  "
                >
                  Email
                </label>

                <Input
                  id={field.name}
                  name={field.name}
                  type="email"
                  value={field.state.value}
                  onChange={(event) =>
                    field.handleChange(
                      event.target.value,
                    )
                  }
                  autoComplete="email"
                />

                {!field.state.meta.isValid && (
                  <p className="mt-1 text-sm text-app-danger">
                    {field.state.meta.errors.join(", ")}
                  </p>
                )}
              </div>
            )}
          </form.Field>

          <form.Field
            name="password"
            validators={{
              onChange: ({ value }) =>
                value.length < 8
                  ? "La contraseña debe tener al menos 8 caracteres"
                  : undefined,
            }}
          >
            {(field) => (
              <div>
                <label
                  htmlFor={field.name}
                  className="
                    mb-1
                    block
                    font-medium
                    text-app-text
                  "
                >
                  Contraseña
                </label>

                <Input
                  id={field.name}
                  name={field.name}
                  type="password"
                  value={field.state.value}
                  onChange={(event) =>
                    field.handleChange(
                      event.target.value,
                    )
                  }
                  autoComplete="new-password"
                />

                {!field.state.meta.isValid && (
                  <p className="mt-1 text-sm text-app-danger">
                    {field.state.meta.errors.join(", ")}
                  </p>
                )}
              </div>
            )}
          </form.Field>

          {errorMessage && (
            <p className="text-sm text-app-danger">
              {errorMessage}
            </p>
          )}

          <button
            type="submit"
            disabled={isPending}
            className="
              w-full
              rounded-lg
              bg-app-primary
              px-4
              py-2
              font-semibold
              text-white
              transition
              hover:opacity-90
              disabled:opacity-50
            "
          >
            {isPending
              ? "Registrando..."
              : "Registrarse"}
          </button>

          <p className="text-center text-sm text-app-text/70">
            ¿Ya tienes una cuenta?{" "}
            <Link
              to="/login"
              className="
                font-semibold
                text-app-primary
              "
            >
              Iniciar sesión
            </Link>
          </p>
        </form>
      </div>
    </main>
  );
};

export default RegisterPage;